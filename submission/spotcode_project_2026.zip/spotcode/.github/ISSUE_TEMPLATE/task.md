---
name: タスク (Task)
about: 期限つきの作業アイテム。spotcode-sns のプロフィール Open-issues カードに拾われます。
title: ""
labels: ["task"]
assignees: []
---

**期限**: YYYY-MM-DD
**spotcode表示**: する

<!-- 表示しない場合は「する」を「しない」に変更してください。 -->

<!-- 時刻を含めたいときは YYYY-MM-DD HH:MM (24h)。時刻を省くと "その日いっぱい" 扱い。 -->

## やること
- [ ] TODO 1
- [ ] TODO 2

## 詳細
何をやるか / なぜやるか / 完了条件、など自由に。
